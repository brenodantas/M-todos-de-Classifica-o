import numpy as np
from scipy.stats import multivariate_normal
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix

# Gerando dados sintéticos para três classes
mean_class1 = [2, 2]
cov_class1 = [[1, 0.5], [0.5, 1]]
mean_class2 = [6, 6]
cov_class2 = [[1, -0.5], [-0.5, 1]]
mean_class3 = [10, 2]
cov_class3 = [[1, 0.3], [0.3, 1]]

np.random.seed(42)
class1 = np.random.multivariate_normal(mean_class1, cov_class1, 100)
class2 = np.random.multivariate_normal(mean_class2, cov_class2, 100)
class3 = np.random.multivariate_normal(mean_class3, cov_class3, 100)

data = np.vstack((class1, class2, class3))
labels = np.array([0] * 100 + [1] * 100 + [2] * 100)

# Função para o Classificador Bayes Completo
class BayesClassifier:
    def __init__(self):
        self.means = {}
        self.covariances = {}
        self.priors = {}

    def fit(self, X, y):
        classes = np.unique(y)
        for cls in classes:
            X_cls = X[y == cls]
            self.means[cls] = np.mean(X_cls, axis=0)
            self.covariances[cls] = np.cov(X_cls, rowvar=False)
            self.priors[cls] = X_cls.shape[0] / X.shape[0]

    def predict(self, X):
        predictions = []
        for x in X:
            posteriors = []
            for cls in self.means:
                likelihood = multivariate_normal.pdf(x, mean=self.means[cls], cov=self.covariances[cls])
                posterior = likelihood * self.priors[cls]
                posteriors.append(posterior)
            predictions.append(np.argmax(posteriors))
        return np.array(predictions)

# Configuração e divisão dos dados
train_size = 0.7
X_train, X_test, y_train, y_test = train_test_split(data, labels, train_size=train_size, random_state=42)

# Treinamento e classificação usando Bayes Completo
bayes_classifier = BayesClassifier()
bayes_classifier.fit(X_train, y_train)
y_pred = bayes_classifier.predict(X_test)

# Cálculo das métricas de avaliação
accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred, average='weighted')
conf_matrix = confusion_matrix(y_test, y_pred)

print("Acurácia:", accuracy)
print("F1-Score:", f1)
print("Matriz de Confusão:\n", conf_matrix)
