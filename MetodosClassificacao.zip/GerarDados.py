import numpy as np
import matplotlib.pyplot as plt

# Definindo médias e covariâncias para três classes
mean_class1 = [2, 2]
cov_class1 = [[1, 0.5], [0.5, 1]]
mean_class2 = [6, 6]
cov_class2 = [[1, -0.5], [-0.5, 1]]
mean_class3 = [10, 2]
cov_class3 = [[1, 0.3], [0.3, 1]]

# Gerando amostras aleatórias para cada classe
np.random.seed(42)
class1 = np.random.multivariate_normal(mean_class1, cov_class1, 100)
class2 = np.random.multivariate_normal(mean_class2, cov_class2, 100)
class3 = np.random.multivariate_normal(mean_class3, cov_class3, 100)

# Visualização dos dados gerados em um gráfico de dispersão
plt.figure(figsize=(8, 6))
plt.scatter(class1[:, 0], class1[:, 1], color='blue', label='Classe 1')
plt.scatter(class2[:, 0], class2[:, 1], color='green', label='Classe 2')
plt.scatter(class3[:, 0], class3[:, 1], color='red', label='Classe 3')
plt.xlabel('X1')
plt.ylabel('X2')
plt.title('Dados Sintéticos - Classes Gaussianas Multivariadas em 2D')
plt.legend()
plt.show()
