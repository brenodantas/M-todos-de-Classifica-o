from sklearn.datasets import load_wine
import pandas as pd

# Carregar a base de dados Wine
wine_data = load_wine()
X = wine_data.data
y = wine_data.target

# Convertendo para um DataFrame para facilitar a análise
wine_df = pd.DataFrame(X, columns=wine_data.feature_names)
wine_df['target'] = y

# Exploração dos dados
num_classes = len(wine_data.target_names)
num_features = X.shape[1]
num_samples = X.shape[0]

print("Número de classes:", num_classes)
print("Número de atributos:", num_features)
print("Número total de amostras:", num_samples)
print("\nResumo dos dados:\n", wine_df.describe())
print("\nDistribuição das classes:\n", wine_df['target'].value_counts())
