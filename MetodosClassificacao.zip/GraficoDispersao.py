import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn.model_selection import train_test_split
from scipy.stats import multivariate_normal, norm

# Gerando dados sintéticos para três classes
mean_class1 = [2, 2]
cov_class1 = [[1, 0.5], [0.5, 1]]
mean_class2 = [6, 6]
cov_class2 = [[1, -0.5], [-0.5, 1]]
mean_class3 = [10, 2]
cov_class3 = [[1, 0.3], [0.3, 1]]

np.random.seed(42)
class1 = np.random.multivariate_normal(mean_class1, cov_class1, 100)
class2 = np.random.multivariate_normal(mean_class2, cov_class2, 100)
class3 = np.random.multivariate_normal(mean_class3, cov_class3, 100)

data = np.vstack((class1, class2, class3))
labels = np.array([0] * 100 + [1] * 100 + [2] * 100)

# Dividindo os dados em conjuntos de treino e teste
train_size = 0.7
X_train, X_test, y_train, y_test = train_test_split(data, labels, train_size=train_size, random_state=42)

# Configuração das cores para as regiões de decisão
cmap_light = ListedColormap(['#FFAAAA', '#AAFFAA', '#AAAAFF'])
cmap_bold = ['#FF0000', '#00FF00', '#0000FF']

# Função para KNN
def knn(X_train, y_train, X_test, k=3, distance_metric='euclidean'):
    distances = np.zeros((X_test.shape[0], X_train.shape[0]))
    for i, test_point in enumerate(X_test):
        if distance_metric == 'euclidean':
            distances[i, :] = np.sqrt(np.sum((X_train - test_point) ** 2, axis=1))
        elif distance_metric == 'manhattan':
            distances[i, :] = np.sum(np.abs(X_train - test_point), axis=1)
        elif distance_metric == 'chebyshev':
            distances[i, :] = np.max(np.abs(X_train - test_point), axis=1)
    y_pred = []
    for dist in distances:
        neighbor_indices = np.argsort(dist)[:k]
        neighbor_classes = y_train[neighbor_indices]
        predicted_class = np.bincount(neighbor_classes).argmax()
        y_pred.append(predicted_class)
    return np.array(y_pred)

# Função para plotar regiões de decisão
def plot_decision_regions(classifier, X_train, y_train, title, k=None, distance_metric=None):
    x_min, x_max = X_train[:, 0].min() - 1, X_train[:, 0].max() + 1
    y_min, y_max = X_train[:, 1].min() - 1, X_train[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1), np.arange(y_min, y_max, 0.1))

    # Obter predições para cada ponto da grade
    if k and distance_metric:
        Z = knn(X_train, y_train, np.c_[xx.ravel(), yy.ravel()], k=k, distance_metric=distance_metric)
    else:
        Z = classifier.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)

    plt.figure(figsize=(8, 6))
    plt.contourf(xx, yy, Z, cmap=cmap_light)
    plt.scatter(X_train[:, 0], X_train[:, 1], c=y_train, cmap=ListedColormap(cmap_bold), edgecolor='k', s=30)
    plt.xlabel('X1')
    plt.ylabel('X2')
    plt.title(title)
    plt.show()

# Visualização das regiões de decisão para KNN
plot_decision_regions(None, X_train, y_train, title='Regiões de Decisão - KNN (k=5, Euclidean)', k=5, distance_metric='euclidean')

# Classe para Bayes Completo
class BayesClassifier:
    def __init__(self):
        self.means = {}
        self.covariances = {}
        self.priors = {}
    def fit(self, X, y):
        classes = np.unique(y)
        for cls in classes:
            X_cls = X[y == cls]
            self.means[cls] = np.mean(X_cls, axis=0)
            self.covariances[cls] = np.cov(X_cls, rowvar=False)
            self.priors[cls] = X_cls.shape[0] / X.shape[0]
    def predict(self, X):
        predictions = []
        for x in X:
            posteriors = []
            for cls in self.means:
                likelihood = multivariate_normal.pdf(x, mean=self.means[cls], cov=self.covariances[cls])
                posterior = likelihood * self.priors[cls]
                posteriors.append(posterior)
            predictions.append(np.argmax(posteriors))
        return np.array(predictions)

# Treinamento e visualização para Bayes Completo
bayes_classifier = BayesClassifier()
bayes_classifier.fit(X_train, y_train)
plot_decision_regions(bayes_classifier, X_train, y_train, title='Regiões de Decisão - Bayes Completo')

# Classe para Naïve Bayes
class NaiveBayesClassifier:
    def __init__(self):
        self.means = {}
        self.stds = {}
        self.priors = {}
    def fit(self, X, y):
        classes = np.unique(y)
        for cls in classes:
            X_cls = X[y == cls]
            self.means[cls] = np.mean(X_cls, axis=0)
            self.stds[cls] = np.std(X_cls, axis=0, ddof=1)
            self.priors[cls] = X_cls.shape[0] / X.shape[0]
    def predict(self, X):
        predictions = []
        for x in X:
            posteriors = []
            for cls in self.means:
                likelihood = np.prod(norm.pdf(x, self.means[cls], self.stds[cls]))
                posterior = likelihood * self.priors[cls]
                posteriors.append(posterior)
            predictions.append(np.argmax(posteriors))
        return np.array(predictions)

# Treinamento e visualização para Naïve Bayes
naive_bayes_classifier = NaiveBayesClassifier()
naive_bayes_classifier.fit(X_train, y_train)
plot_decision_regions(naive_bayes_classifier, X_train, y_train, title='Regiões de Decisão - Naïve Bayes')
