from sklearn.datasets import load_wine  # Importação adicionada
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB

# Carregar e preparar a base de dados Wine
wine_data = load_wine()
X = wine_data.data
y = wine_data.target

# Função para avaliação de modelos
def evaluate_model(classifier, X_train, X_test, y_train, y_test):
    classifier.fit(X_train, y_train)
    y_pred = classifier.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred, average='weighted')
    conf_matrix = confusion_matrix(y_test, y_pred)
    return accuracy, f1, conf_matrix

# Configuração de parâmetros para experimentação
k_values = [3, 5, 7]
train_sizes = [0.6, 0.7, 0.8]

# Resultados para diferentes configurações de KNN
print("Resultados para o KNN:")
for k in k_values:
    for train_size in train_sizes:
        X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=train_size, random_state=42)
        knn = KNeighborsClassifier(n_neighbors=k, metric='euclidean')
        accuracy, f1, conf_matrix = evaluate_model(knn, X_train, X_test, y_train, y_test)
        print(f"\nKNN com k={k}, tamanho de treinamento={train_size*100}%")
        print("Acurácia:", accuracy)
        print("F1-Score:", f1)
        print("Matriz de Confusão:\n", conf_matrix)

# Resultados para o Classificador Bayes Completo
print("\nResultados para o Classificador Bayes Completo:")
for train_size in train_sizes:
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=train_size, random_state=42)
    bayes_classifier = GaussianNB()
    accuracy, f1, conf_matrix = evaluate_model(bayes_classifier, X_train, X_test, y_train, y_test)
    print(f"\nClassificador Bayes Completo, tamanho de treinamento={train_size*100}%")
    print("Acurácia:", accuracy)
    print("F1-Score:", f1)
    print("Matriz de Confusão:\n", conf_matrix)

# Resultados para o Naïve Bayes
print("\nResultados para o Naïve Bayes:")
naive_bayes_classifier = GaussianNB()  # Já implementado como Naïve Bayes Gaussiano

for train_size in train_sizes:
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=train_size, random_state=42)
    accuracy, f1, conf_matrix = evaluate_model(naive_bayes_classifier, X_train, X_test, y_train, y_test)
    print(f"\nNaïve Bayes, tamanho de treinamento={train_size*100}%")
    print("Acurácia:", accuracy)
    print("F1-Score:", f1)
    print("Matriz de Confusão:\n", conf_matrix)
