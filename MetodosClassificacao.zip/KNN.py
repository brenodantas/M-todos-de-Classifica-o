from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import numpy as np

def knn(X_train, y_train, X_test, k=3, distance_metric='euclidean'):
    distances = np.zeros((X_test.shape[0], X_train.shape[0]))

    # Calcula a distância entre cada ponto de teste e cada ponto de treino
    for i, test_point in enumerate(X_test):
        if distance_metric == 'euclidean':
            distances[i, :] = np.sqrt(np.sum((X_train - test_point)**2, axis=1))
        elif distance_metric == 'manhattan':
            distances[i, :] = np.sum(np.abs(X_train - test_point), axis=1)
        elif distance_metric == 'chebyshev':
            distances[i, :] = np.max(np.abs(X_train - test_point), axis=1)

    # Identifica os k vizinhos mais próximos e prevê a classe com base na maioria
    y_pred = []
    for dist in distances:
        neighbor_indices = np.argsort(dist)[:k]
        neighbor_classes = y_train[neighbor_indices]
        predicted_class = np.bincount(neighbor_classes).argmax()
        y_pred.append(predicted_class)

    return np.array(y_pred)

# Definindo as classes como no código fornecido
mean_class1 = [2, 2]
cov_class1 = [[1, 0.5], [0.5, 1]]
mean_class2 = [6, 6]
cov_class2 = [[1, -0.5], [-0.5, 1]]
mean_class3 = [10, 2]
cov_class3 = [[1, 0.3], [0.3, 1]]

# Gerando amostras para cada classe
np.random.seed(42)
class1 = np.random.multivariate_normal(mean_class1, cov_class1, 100)
class2 = np.random.multivariate_normal(mean_class2, cov_class2, 100)
class3 = np.random.multivariate_normal(mean_class3, cov_class3, 100)

# Construindo o conjunto de dados e os rótulos
data = np.vstack((class1, class2, class3))
labels = np.array([0] * 100 + [1] * 100 + [2] * 100)

# Parâmetros de configuração
k = 5
distance_metric = 'euclidean'
train_size = 0.7  # Divisão dos dados

# Dividindo os dados em conjuntos de treinamento e teste
X_train, X_test, y_train, y_test = train_test_split(data, labels, train_size=train_size, random_state=42)

# Classificação usando KNN
y_pred = knn(X_train, y_train, X_test, k=k, distance_metric=distance_metric)

# Cálculo das métricas de avaliação
accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred, average='weighted')
conf_matrix = confusion_matrix(y_test, y_pred)

print("Acurácia:", accuracy)
print("F1-Score:", f1)
print("Matriz de Confusão:\n", conf_matrix)
